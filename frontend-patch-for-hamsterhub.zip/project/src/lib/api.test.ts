import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';

const payload = { building: 'ECC Building', roomNumber: '402', current: 20, voltage: 220, motion: false };
const backendRoom = {
  id: 'ecc-building-402', building: 'ECC Building', roomNumber: '402', current: 20,
  motion: false, status: 'Energy Waste', zone: 'Simulated', lastUpdated: 1,
};
const json = (status: number, body: unknown) =>
  Promise.resolve(new Response(JSON.stringify(body), { status, headers: { 'Content-Type': 'application/json' } }));

async function load() {
  vi.resetModules();
  vi.stubEnv('VITE_API_URL', 'http://localhost:8799/');
  return import('./api');
}

beforeEach(() => vi.stubGlobal('fetch', vi.fn()));
afterEach(() => {
  vi.unstubAllEnvs();
  vi.unstubAllGlobals();
});

describe('upsertRoom with VITE_API_URL set', () => {
  it('uses the backend response and marks source=backend', async () => {
    const api = await load();
    vi.mocked(fetch).mockImplementation(() => json(200, { room: backendRoom, reasons: ['r1'] }));
    const r = await api.upsertRoom(payload);
    expect(r.source).toBe('backend');
    expect(r.room.reasons).toEqual(['r1']);
    expect(vi.mocked(fetch).mock.calls[0][0]).toBe('http://localhost:8799/api/telemetry');
  });

  it('network error -> local fallback, flagged so UI cannot claim success', async () => {
    const api = await load();
    vi.mocked(fetch).mockRejectedValue(new TypeError('Failed to fetch'));
    const r = await api.upsertRoom(payload);
    expect(r.source).toBe('local');
    expect(r.fallbackReason).toContain('Failed to fetch');
    expect(r.room.status).toBe('Energy Waste');
  });

  it('HTTP 5xx -> local fallback with the status in the reason', async () => {
    const api = await load();
    vi.mocked(fetch).mockImplementation(() => json(500, { errors: ['internal error'] }));
    const r = await api.upsertRoom(payload);
    expect(r.source).toBe('local');
    expect(r.fallbackReason).toBe('HTTP 500');
  });

  it('HTTP 4xx -> throws ApiRejected carrying the backend validation message', async () => {
    const api = await load();
    vi.mocked(fetch).mockImplementation(() => json(400, { errors: ['current must be a number between 0 and 100 (A)'] }));
    const err = await api.upsertRoom({ ...payload, current: 999 }).catch((e: unknown) => e);
    expect(err).toBeInstanceOf(api.ApiRejected);
    expect((err as Error).message).toContain('current must be a number');
  });

  it('recovers: backend works again after a failure', async () => {
    const api = await load();
    vi.mocked(fetch).mockRejectedValueOnce(new TypeError('Failed to fetch'));
    expect((await api.upsertRoom(payload)).source).toBe('local');
    vi.mocked(fetch).mockImplementation(() => json(200, { room: backendRoom, reasons: [] }));
    expect((await api.upsertRoom(payload)).source).toBe('backend');
  });
});

describe('checkHealth', () => {
  it('true on {ok:true}, false on network error', async () => {
    const api = await load();
    vi.mocked(fetch).mockImplementation(() => json(200, { ok: true }));
    expect(await api.checkHealth()).toBe(true);
    vi.mocked(fetch).mockRejectedValue(new TypeError('Failed to fetch'));
    expect(await api.checkHealth()).toBe(false);
  });
});
